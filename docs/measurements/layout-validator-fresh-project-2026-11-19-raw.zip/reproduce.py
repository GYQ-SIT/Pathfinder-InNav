"""Rebuild and repeat the archived T11 check using only this ZIP and a local UE 5.8 installation."""
import argparse, collections, hashlib, json, os, pathlib, subprocess

p = argparse.ArgumentParser()
p.add_argument('--engine', default=os.environ.get('UE_ROOT', r'C:\Program Files\Epic Games\UE_5.8'))
p.add_argument('--skip-build', action='store_true')
a = p.parse_args()
root = pathlib.Path(__file__).resolve().parent
engine = pathlib.Path(a.engine)
project = root/'project/T11ValidatorProbe.uproject'
output = root/'rerun'
output.mkdir(exist_ok=True)
manifest = json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
for member, digest in manifest['files_sha256'].items():
    assert sha(root/member) == digest, f'Archive file changed: {member}'
if not a.skip_build:
    for target in ['T11ValidatorProbeEditor', 'T11ValidatorProbe']:
        command = ['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command',
                   '& $env:T11_BUILD_SCRIPT $env:T11_BUILD_TARGET Win64 Development "-Project=$env:T11_PROJECT" -WaitMutex -DisableAdaptiveUnity; exit $LASTEXITCODE']
        build_env = {**os.environ, 'T11_BUILD_SCRIPT':str(engine/'Engine/Build/BatchFiles/Build.bat'),
                     'T11_BUILD_TARGET':target, 'T11_PROJECT':str(project)}
        with (output/(target+'-build.log')).open('w') as log:
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, env=build_env)
        assert result.returncode == 0, f'Build failed: {target}; see rerun logs'
for case in manifest['cases']:
    input_file = root/case['input_member']
    report = output/(case['name']+'-report.json')
    before = sha(input_file)
    command = [str(engine/'Engine/Binaries/Win64/UnrealEditor-Cmd.exe'), str(project), '-run=T11Validate',
               f'-Input={input_file}', f'-Report={report}', '-unattended', '-nullrhi', '-nosplash', '-nosound']
    with (output/(case['name']+'-console.log')).open('w') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=180)
    data = json.loads(report.read_text(encoding='utf-8-sig'))
    meta = json.loads(pathlib.Path(str(report)+'.meta.json').read_text(encoding='utf-8-sig'))
    assert result.returncode == case['exit_code'], case['name']
    assert before == sha(input_file), 'Validation changed input'
    assert not meta['sqliteModuleLoaded'] and not meta['productModuleLoaded']
    assert not meta['productDataDirectoryExists'] and meta['validationProviderRegistered']
    assert meta['validationWidgetClassPath'] == '' and data['navigationChecked'] is False
    assert dict(collections.Counter(i['severity'] for i in data['issues'])) == case['issues'], case['name']
    assert sorted(set(i['rule'] for i in data['issues'])) == case['rules'], case['name']
    print(case['name'], 'PASS', flush=True)
print('Both target builds and all 12 fixture results reproduced.' if not a.skip_build else 'All 12 fixture results reproduced.')
