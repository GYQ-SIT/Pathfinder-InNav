T11 fresh-project evidence — plugin 1.2.0
Source commit: 3ceab9457ec6079f6b24d526cf33d19c97a49139
UE 5.8.2, Windows / Win64 Development. Editor and Game targets built successfully.
The Game target was not cooked, packaged or launched.

logs/: unmodified successful build and 12 commandlet run logs.
reports/: unmodified exported validator reports and module/UI metadata.
project/: exact fresh project source, plugin source and input fixtures; no Binaries/Intermediate.
MANIFEST.json: SHA-256 of every member except the manifest itself, plus expected case outcomes.

To repeat, extract to a short local path outside a synced folder, e.g. C:\Temp\T11.
With Python 3: python reproduce.py --engine "C:\Program Files\Epic Games\UE_5.8"
This rebuilds both targets, verifies the archive hashes and replays all 12 cases.
--skip-build is available after building. New reports/logs go under rerun/.
No npm token, SQL server, SQLite plugin or product Data directory is required.
CONNECTOR_ENCLOSED is a warning: affected cases deliberately exit 0.
navigationChecked=false means no physical route reachability was checked.
