#include "T11ValidateCommandlet.h"
#include "LayoutValidation.h"
#include "LayoutToolRegistry.h"
#include "Dom/JsonObject.h"
#include "HAL/FileManager.h"
#include "Misc/EngineVersion.h"
#include "Misc/FileHelper.h"
#include "Misc/Parse.h"
#include "Misc/Paths.h"
#include "Modules/ModuleManager.h"
#include "Serialization/JsonSerializer.h"
#include "Serialization/JsonWriter.h"
IMPLEMENT_MODULE(FDefaultModuleImpl, T11ValidatorProbeEditor);
UT11ValidateCommandlet::UT11ValidateCommandlet()
{
    IsClient = false; IsServer = false; IsEditor = true; LogToConsole = true;
}
int32 UT11ValidateCommandlet::Main(const FString& Params)
{
    FString Input, Output;
    if (!FParse::Value(*Params, TEXT("Input="), Input) || !FParse::Value(*Params, TEXT("Report="), Output)) return 2;
    if (FPaths::ConvertRelativePathToFull(Input).Equals(FPaths::ConvertRelativePathToFull(Output), ESearchCase::IgnoreCase)) return 2;
    FModuleManager::LoadModuleChecked<IModuleInterface>(TEXT("InNaviLayoutValidator"));
    const auto Report = LayoutValidation::ValidateFile(Input);
    if (!LayoutValidation::ExportReport(Report, Output)) return 2;
    auto Meta = MakeShared<FJsonObject>();
    const bool bSQLite = FModuleManager::Get().IsModuleLoaded(TEXT("SQLiteCore")) || FModuleManager::Get().IsModuleLoaded(TEXT("SQLiteSupport"));
    const bool bProduct = FModuleManager::Get().IsModuleLoaded(TEXT("InNavi"));
    Meta->SetStringField(TEXT("engineVersion"), FEngineVersion::Current().ToString());
    Meta->SetBoolField(TEXT("sqliteModuleLoaded"), bSQLite);
    Meta->SetBoolField(TEXT("productModuleLoaded"), bProduct);
    Meta->SetBoolField(TEXT("productDataDirectoryExists"), IFileManager::Get().DirectoryExists(*(FPaths::ProjectDir() / TEXT("Data"))));
    bool bRegistered = false;
    FString WidgetPath;
    for (const auto& Tool : LayoutTools::FRegistry::Get().Tools(LayoutTools::EScreen::Interior))
    {
        if (Tool.Id == TEXT("Validation")) { bRegistered = true; WidgetPath = Tool.WidgetClassPath; }
    }
    Meta->SetBoolField(TEXT("validationProviderRegistered"), bRegistered);
    Meta->SetStringField(TEXT("validationWidgetClassPath"), WidgetPath);
    FString Text;
    if (!FJsonSerializer::Serialize(Meta, TJsonWriterFactory<>::Create(&Text)) || !FFileHelper::SaveStringToFile(Text, *(Output + TEXT(".meta.json")))) return 2;
    UE_LOG(LogTemp, Display, TEXT("T11 probe: %d errors, %d warnings; SQL=%d, product=%d, registered=%d"), Report.Count(LayoutValidation::ESeverity::Error), Report.Count(LayoutValidation::ESeverity::Warning), bSQLite, bProduct, bRegistered);
    if (bSQLite || bProduct || !bRegistered) return 3;
    return Report.HasErrors() ? 1 : 0;
}
