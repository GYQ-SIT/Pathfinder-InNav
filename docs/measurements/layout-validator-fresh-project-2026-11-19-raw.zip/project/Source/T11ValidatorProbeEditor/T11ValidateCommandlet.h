#pragma once
#include "Commandlets/Commandlet.h"
#include "T11ValidateCommandlet.generated.h"
UCLASS()
class UT11ValidateCommandlet : public UCommandlet
{
    GENERATED_BODY()
public:
    UT11ValidateCommandlet();
    virtual int32 Main(const FString& Params) override;
};
