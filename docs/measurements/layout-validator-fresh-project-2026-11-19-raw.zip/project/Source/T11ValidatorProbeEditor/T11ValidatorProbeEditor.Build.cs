using UnrealBuildTool;
public class T11ValidatorProbeEditor : ModuleRules
{
    public T11ValidatorProbeEditor(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
        PrivateDependencyModuleNames.AddRange(new[] { "Core", "CoreUObject", "Engine", "Json", "InNaviLayoutValidator" });
    }
}
