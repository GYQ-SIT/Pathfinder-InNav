using UnrealBuildTool;
public class T11ValidatorProbeEditorTarget : TargetRules
{
    public T11ValidatorProbeEditorTarget(TargetInfo Target) : base(Target)
    {
        Type = TargetType.Editor;
        DefaultBuildSettings = BuildSettingsVersion.V7;
        IncludeOrderVersion = EngineIncludeOrderVersion.Unreal5_8;
        ExtraModuleNames.AddRange(new[] { "T11ValidatorProbe", "T11ValidatorProbeEditor" });
    }
}
