using UnrealBuildTool;
public class T11ValidatorProbeTarget : TargetRules
{
    public T11ValidatorProbeTarget(TargetInfo Target) : base(Target)
    {
        Type = TargetType.Game;
        DefaultBuildSettings = BuildSettingsVersion.V7;
        IncludeOrderVersion = EngineIncludeOrderVersion.Unreal5_8;
        ExtraModuleNames.AddRange(new[] { "T11ValidatorProbe" });
    }
}
