using UnrealBuildTool;
public class T11ValidatorProbe : ModuleRules
{
    public T11ValidatorProbe(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
        PrivateDependencyModuleNames.AddRange(new[] { "Core", "CoreUObject", "Engine", "InNaviLayoutValidator" });
    }
}
